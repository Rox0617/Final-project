package com.demo.tianqi.util;

/**
 * @desc 公共属性
 **/
public class Constants {
    /**
     * APP_ID:ovxjhvjvlebsxgzl
     * APP_SECRET:cmpTT1pLS3RiTjZYdFBPMHhVbHRSdz09
     */
    public static final String APP_ID = "ovxjhvjvlebsxgzl";
    public static final String APP_SECRET = "cmpTT1pLS3RiTjZYdFBPMHhVbHRSdz09";

}
